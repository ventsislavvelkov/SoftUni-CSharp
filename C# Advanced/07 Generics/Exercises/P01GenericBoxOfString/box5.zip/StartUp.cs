﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace P01GenericBoxOfString
{
    class StartUp
    {
        static void Main(string[] args)
        {
            var n = int.Parse(Console.ReadLine());
            var elements =  new List<string>();

            for (int i = 0; i < n; i++)
            {
                var input = Console.ReadLine();
                elements.Add(input);
            }

            var box = new Box<string>(elements);
            var element = Console.ReadLine();

           var countOfGreaterElements = box.CountElements(elements, element);
           Console.WriteLine(countOfGreaterElements);





        }
    }
}
