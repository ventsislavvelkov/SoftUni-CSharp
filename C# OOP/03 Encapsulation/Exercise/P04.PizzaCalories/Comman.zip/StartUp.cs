﻿using System;
using P04.PizzaCalories.Core;

namespace P04.PizzaCalories
{
    class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
            
        }
    }
}
