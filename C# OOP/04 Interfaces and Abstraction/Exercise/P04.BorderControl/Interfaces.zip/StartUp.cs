﻿using System;
using P04.BorderControl.Core;

namespace P04.BorderControl
{
    class StartUp
    {
        static void Main(string[] args)
        {
            var engine = new Engine();
            engine.Run();
        }
    }
}
