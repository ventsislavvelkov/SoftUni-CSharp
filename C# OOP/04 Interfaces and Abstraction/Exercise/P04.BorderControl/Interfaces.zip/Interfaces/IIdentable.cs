﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P04.BorderControl.Interfaces
{
    public interface IIdentable
    {
        string Id { get; }
    }
}
