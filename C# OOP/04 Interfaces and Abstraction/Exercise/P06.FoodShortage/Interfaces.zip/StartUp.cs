﻿using System;
using P06.FoodShortage.Core;

namespace P06.FoodShortage
{
    class StartUp
    {
        static void Main(string[] args)
        {
            var engine = new Engine();
                engine.Run();
        }
    }
}
