﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P05.BirthdayCelebrations.Interfaces
{
   public interface IBirthdate
    {
        string Birthday { get; }

        string Name { get; }
    }
}
