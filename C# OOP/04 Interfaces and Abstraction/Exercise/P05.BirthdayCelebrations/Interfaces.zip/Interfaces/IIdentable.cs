﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P05.BirthdayCelebrations.Interfaces
{
    public interface IIdentable
    {
        string Id { get; }
    }
}
