﻿using System;
using P05.BirthdayCelebrations.Core;

namespace P05.BirthdayCelebrations
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            var engine = new Engine();
            engine.Run();
        }
    }
}
