﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03Telephony.Comman
{
    public static class GlobalExceptions
    {
        public static string WrongUrlExceptionMessage = "Invalid URL!";

        public static string WrongNumberExceptionMessage = "Invalid number!";
    }
}
