﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03Telephony.Interfaces
{
    public interface IBrowseble
    {
        string Browser(string siteName);
    }
}
