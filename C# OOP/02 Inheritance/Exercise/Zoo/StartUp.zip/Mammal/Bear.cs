﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Zoo.Mammal
{
    public class Bear : Mammal
    {
        public Bear(string name) 
            : base(name)
        {
        }
    }
}
