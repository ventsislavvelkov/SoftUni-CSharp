﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Zoo.Reptile
{
    public class Snake : Lizard
    {
        public Snake(string name) 
            : base(name)
        {
        }
    }
}
