﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Zoo.Reptile
{
   public class Lizard : Animal
    {
        public Lizard(string name) 
            :base(name)
        {

        }
    }
}
