﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace P01_RawData
{
    public class RawData
    {
        static void Main(string[] args)
        {
            ProgramEngine engine = new ProgramEngine();
            engine.Run();
        }
    }
}
