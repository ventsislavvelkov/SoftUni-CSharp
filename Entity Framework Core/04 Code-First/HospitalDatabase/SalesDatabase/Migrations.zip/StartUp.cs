﻿using System;

namespace SalesDatabase
{
   public class StartUp
    {
       public static void Main(string[] args)
        {
            
        }
    }
}
