﻿namespace P01_StudentSystem.Data
{
    public static class Connection
    {
        public const string DefaultConnection = @"Server=.;Database=StudentSystem;Integrated Security=True";
    }
}
